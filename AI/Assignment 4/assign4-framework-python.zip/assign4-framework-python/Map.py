# Author Fan Zhang
class Map:
    def __init__(self):
        self.borders = []
        self.states = []