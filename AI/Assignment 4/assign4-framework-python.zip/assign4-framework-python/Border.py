#Author: Fan Zhang
#A class representing a border between two states.
class Border:
    def __init__(self, index1, index2):
        self.index1 = index1
        self.index2 = index2